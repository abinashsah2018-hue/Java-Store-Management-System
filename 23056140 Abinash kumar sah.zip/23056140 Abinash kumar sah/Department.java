public class Department extends Store {
    // Fields specific to the Department class
    private String productName;       // Name of the product
    private double markedPrice;       // Price before any discount
    private double sellingPrice;      // Price after discount
    private boolean isInSales;        // Indicates if the product is currently in sales

    // Constructor to initialize a Department object
    public Department(int storeId, String storeName, String location, String openingHour,
                      double totalSales, double totalDiscount, String productName, double markedPrice) {
        // Call the superclass (Store) constructor to initialize common store attributes
        super(storeId, storeName, location, openingHour);
        
        // Initialize store totals using superclass methods
        this.setTotalSales(totalSales);
        this.setTotalDiscount(totalDiscount);
        
        // Initialize Department-specific fields
        this.productName = productName;
        this.markedPrice = markedPrice;
        this.sellingPrice = 0.0; // Default selling price is set to 0
        this.isInSales = true;   // Default value indicating the product is in sales
    }

    // Getter for product name
    public String getProductName() {
        return productName;
    }

    // Getter for marked price
    public double getMarkedPrice() {
        return markedPrice;
    }

    // Getter for selling price
    public double getSellingPrice() {
        return sellingPrice;
    }

    // Setter for marked price
    public void setMarkedPrice(double newMarkedPrice) {
        markedPrice = newMarkedPrice;
    }

    // Method to calculate the discount price based on the sales status
    public void calculateDiscountPrice(boolean isInSales) {
        double discountPercentage;
        
        // Check if the product is in sales to apply the discount
        if (isInSales) {
            // Determine the discount percentage based on the marked price
            if (markedPrice >= 5000) {
                discountPercentage = 0.20; // 20% discount for prices >= 5000
            } else if (markedPrice >= 3000) {
                discountPercentage = 0.10; // 10% discount for prices >= 3000
            } else if (markedPrice >= 1000) {
                discountPercentage = 0.05; // 5% discount for prices >= 1000
            } else {
                discountPercentage = 0.0;  // No discount for prices < 1000
            }
            
            // Calculate the selling price after applying the discount
            sellingPrice = markedPrice - (markedPrice * discountPercentage);
            // Update the total discount amount
            setTotalDiscount(markedPrice * discountPercentage);
            // Set isInSales to false after applying the discount
            this.isInSales = false;
        } else {
            // Print a message if the product is not in sales
            System.out.println("Product is not available for sales.");
        }
    }

    // Override toString method to provide a formatted string representation of the Department
    @Override
    public String toString() {
        // Call the superclass toString method to include Store details and append Department-specific details
        return super.toString() + String.format("\nProduct Name: %s\nMarked Price: $%.2f\nSelling Price: $%.2f\nIn Sales: %b",
                productName, markedPrice, sellingPrice, !isInSales);
    }
}
