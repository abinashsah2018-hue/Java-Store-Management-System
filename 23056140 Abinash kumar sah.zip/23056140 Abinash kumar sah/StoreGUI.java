import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class StoreGUI {
    private JFrame frame;
    private JTextField storeIdField;
    private JTextField storeNameField;
    private JTextField locationField;
    private JTextField openingHourField;
    private JTextField totalSalesField;
    private JTextField totalDiscountField;
    private JTextField productNameField;
    private JTextField markedPriceField;
    private JTextField sellingPriceField;
    private JTextField vatInclusivePriceField;
    private JTextField loyaltyPointField;
    private JCheckBox isPaymentOnlineCheckBox;
    private JComboBox<String> purchasedYearComboBox;
    private JButton addDepartmentButton;
    private JButton addRetailerButton;
    private JButton calculateDiscountButton;
    private JButton setLoyaltyPointButton;
    private JButton removeProductButton;
    private JButton displayButton; 
    private JButton clearButton;
    private ArrayList<Store> storeList;

    public static void main(String[] args) {
        // Create and show the GUI on the Event Dispatch Thread
        SwingUtilities.invokeLater(() -> new StoreGUI().createAndShowGUI());
    }

    private void createAndShowGUI() {
        // Create the main frame
        frame = new JFrame("Store Management");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);
        frame.setLayout(new BorderLayout());

        // Create and configure the main panel with GridBagLayout
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new GridBagLayout());
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Initialize text fields
        storeIdField = new JTextField(10);
        storeNameField = new JTextField(10);
        locationField = new JTextField(10);
        openingHourField = new JTextField(10);
        totalSalesField = new JTextField(10);
        totalDiscountField = new JTextField(10);
        productNameField = new JTextField(10);
        markedPriceField = new JTextField(10);
        sellingPriceField = new JTextField(10);
        vatInclusivePriceField = new JTextField(10);
        loyaltyPointField = new JTextField(10);

        // Initialize payment-related components
        isPaymentOnlineCheckBox = new JCheckBox("Payment Online");
        purchasedYearComboBox = new JComboBox<>(new String[]{"2020", "2021", "2022", "2023"});

        // Initialize buttons
        addDepartmentButton = new JButton("Add Department");
        addRetailerButton = new JButton("Add Retailer");
        calculateDiscountButton = new JButton("Calculate Discount Price");
        setLoyaltyPointButton = new JButton("Set Loyalty Point");
        removeProductButton = new JButton("Remove Product");
        displayButton = new JButton("Display");
        clearButton = new JButton("Clear");

        // Initialize the list to store the store objects
        storeList = new ArrayList<>();

        // Add components to the main panel using GridBagLayout
        addComponent(mainPanel, new JLabel("Store ID:"), storeIdField, 0, 0, 1);
        addComponent(mainPanel, new JLabel("Store Name:"), storeNameField, 0, 1, 1);
        addComponent(mainPanel, new JLabel("Location:"), locationField, 0, 2, 1);
        addComponent(mainPanel, new JLabel("Opening Hour:"), openingHourField, 0, 3, 1);
        addComponent(mainPanel, new JLabel("Total Sales:"), totalSalesField, 0, 4, 1);
        addComponent(mainPanel, new JLabel("Total Discount:"), totalDiscountField, 0, 5, 1);
        addComponent(mainPanel, new JLabel("Product Name:"), productNameField, 0, 6, 1);
        addComponent(mainPanel, new JLabel("Marked Price:"), markedPriceField, 0, 7, 1);
        addComponent(mainPanel, new JLabel("Selling Price:"), sellingPriceField, 0, 8, 1);
        addComponent(mainPanel, new JLabel("VAT Inclusive Price:"), vatInclusivePriceField, 0, 9, 1);
        addComponent(mainPanel, new JLabel("Loyalty Point:"), loyaltyPointField, 0, 10, 1);

        // Create and configure the payment options panel
        JPanel paymentPanel = new JPanel();
        paymentPanel.setLayout(new GridBagLayout());
        paymentPanel.setBorder(BorderFactory.createTitledBorder("Payment Options"));

        // Add components to the payment panel
        GridBagConstraints paymentGbc = new GridBagConstraints();
        paymentGbc.insets = new Insets(5, 5, 5, 5);
        paymentGbc.fill = GridBagConstraints.HORIZONTAL;
        paymentGbc.gridx = 0;
        paymentGbc.gridy = 0;
        paymentPanel.add(isPaymentOnlineCheckBox, paymentGbc);
        paymentGbc.gridy = 1;
        paymentPanel.add(new JLabel("Purchased Year:"), paymentGbc);
        paymentGbc.gridx = 1;
        paymentPanel.add(purchasedYearComboBox, paymentGbc);

        // Add the payment panel to the main panel below all other components
        gbc.gridx = 0;
        gbc.gridy = 11;  // Position below all other fields
        gbc.gridwidth = 2; // Span across the grid width
        gbc.fill = GridBagConstraints.BOTH; // Allow it to expand
        mainPanel.add(paymentPanel, gbc);

        // Create and configure the button panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(8, 1, 5, 5));
        buttonPanel.add(addDepartmentButton);
        buttonPanel.add(addRetailerButton);
        buttonPanel.add(calculateDiscountButton);
        buttonPanel.add(setLoyaltyPointButton);
        buttonPanel.add(removeProductButton);
        buttonPanel.add(displayButton);
        buttonPanel.add(clearButton);

        // Add panels to the frame
        frame.add(mainPanel, BorderLayout.CENTER);
        frame.add(buttonPanel, BorderLayout.EAST);

        // Add action listeners for buttons
        addDepartmentButton.addActionListener(new AddDepartmentListener());
        addRetailerButton.addActionListener(new AddRetailerListener());
        calculateDiscountButton.addActionListener(new CalculateDiscountListener());
        setLoyaltyPointButton.addActionListener(new SetLoyaltyPointListener());
        removeProductButton.addActionListener(new RemoveProductListener());
        displayButton.addActionListener(new DisplayListener());
        clearButton.addActionListener(new ClearListener());

        // Make the frame visible
        frame.setVisible(true);
    }

    private void addComponent(JPanel panel, Component label, Component field, int gridx, int gridy, int gridwidth) {
        // Add a label and field to the panel with GridBagLayout
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = gridx;
        gbc.gridy = gridy;
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;
        panel.add(label, gbc);

        gbc.gridx = gridx + 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;
        panel.add(field, gbc);
    }

    // Action listener for adding a department
    private class AddDepartmentListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                int storeId = Integer.parseInt(storeIdField.getText());
                String storeName = storeNameField.getText();
                String location = locationField.getText();
                String openingHour = openingHourField.getText();
                double totalSales = Double.parseDouble(totalSalesField.getText());
                double totalDiscount = Double.parseDouble(totalDiscountField.getText());
                String productName = productNameField.getText();
                double markedPrice = Double.parseDouble(markedPriceField.getText());

                Store store = new Department(storeId, storeName, location, openingHour, totalSales, totalDiscount, productName, markedPrice);
                storeList.add(store);
                JOptionPane.showMessageDialog(frame, "Department added successfully.");
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(frame, "Please enter valid numbers.");
            }
        }
    }

    // Action listener for adding a retailer
    private class AddRetailerListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                int storeId = Integer.parseInt(storeIdField.getText());
                String storeName = storeNameField.getText();
                String location = locationField.getText();
                String openingHour = openingHourField.getText();
                double totalSales = Double.parseDouble(totalSalesField.getText());
                double totalDiscount = Double.parseDouble(totalDiscountField.getText());
                int vatInclusivePrice = Integer.parseInt(vatInclusivePriceField.getText());
                boolean isPaymentOnline = isPaymentOnlineCheckBox.isSelected();
                String purchasedYear = (String) purchasedYearComboBox.getSelectedItem();

                Store store = new Retailer(storeId, storeName, location, openingHour, totalSales, totalDiscount, vatInclusivePrice, isPaymentOnline, purchasedYear);
                storeList.add(store);
                JOptionPane.showMessageDialog(frame, "Retailer added successfully.");
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(frame, "Please enter valid numbers.");
            }
        }
    }

    // Action listener for calculating discount price
    private class CalculateDiscountListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                int storeId = Integer.parseInt(storeIdField.getText());
                for (Store store : storeList) {
                    if (store instanceof Department && store.getStoreId() == storeId) {
                        Department department = (Department) store;
                        department.calculateDiscountPrice(true);
                        sellingPriceField.setText(String.valueOf(department.getSellingPrice()));
                        JOptionPane.showMessageDialog(frame, "Discount price calculated successfully.");
                        return;
                    }
                }
                JOptionPane.showMessageDialog(frame, "Department with this Store ID not found.");
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(frame, "Please enter a valid Store ID.");
            }
        }
    }

    // Action listener for setting loyalty points
    private class SetLoyaltyPointListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                int storeId = Integer.parseInt(storeIdField.getText());
                for (Store store : storeList) {
                    if (store instanceof Retailer && store.getStoreId() == storeId) {
                        Retailer retailer = (Retailer) store;
                        retailer.calculateLoyaltyPoint();
                        loyaltyPointField.setText(String.valueOf(retailer.getLoyaltyPoint()));
                        JOptionPane.showMessageDialog(frame, "Loyalty point set successfully.");
                        return;
                    }
                }
                JOptionPane.showMessageDialog(frame, "Retailer with this Store ID not found.");
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(frame, "Please enter a valid Store ID.");
            }
        }
    }

    // Action listener for removing a product
    private class RemoveProductListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                int storeId = Integer.parseInt(storeIdField.getText());
                for (Store store : storeList) {
                    if (store instanceof Retailer && store.getStoreId() == storeId) {
                        Retailer retailer = (Retailer) store;
                        retailer.removeProduct();
                        JOptionPane.showMessageDialog(frame, "Product removed successfully.");
                        return;
                    }
                }
                JOptionPane.showMessageDialog(frame, "Retailer with this Store ID not found.");
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(frame, "Please enter a valid Store ID.");
            }
        }
    }

    // Action listener for displaying the list of stores
    private class DisplayListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            StringBuilder sb = new StringBuilder();
            for (Store store : storeList) {
                sb.append(store.toString()).append("\n\n");
            }
            JOptionPane.showMessageDialog(frame, sb.toString(), "Store List", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    // Action listener for clearing the input fields
    private class ClearListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            storeIdField.setText("");
            storeNameField.setText("");
            locationField.setText("");
            openingHourField.setText("");
            totalSalesField.setText("");
            totalDiscountField.setText("");
            productNameField.setText("");
            markedPriceField.setText("");
            sellingPriceField.setText("");
            vatInclusivePriceField.setText("");
            loyaltyPointField.setText("");
            isPaymentOnlineCheckBox.setSelected(false);
            purchasedYearComboBox.setSelectedIndex(0);
        }
    }
}
