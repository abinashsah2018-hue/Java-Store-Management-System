public class Retailer extends Store {
    // Fields specific to the Retailer class
    private int vatInclusivePrice;   // Price including VAT
    private int loyaltyPoint;        // Loyalty points for the retailer
    private boolean isPaymentOnline; // Indicates if payment is made online
    private String purchasedYear;    // Year the retailer was purchased

    // Constructor to initialize a Retailer object
    public Retailer(int storeId, String storeName, String location, String openingHour,
                    double totalSales, double totalDiscount, int vatInclusivePrice,
                    boolean isPaymentOnline, String purchasedYear) {
        // Call the superclass (Store) constructor to initialize common store attributes
        super(storeId, storeName, location, openingHour);
        
        // Initialize total sales and discounts using superclass methods
        setTotalSales(totalSales);
        setTotalDiscount(totalDiscount);
        
        // Initialize Retailer-specific fields
        this.vatInclusivePrice = vatInclusivePrice;
        this.purchasedYear = purchasedYear;
        this.loyaltyPoint = 0; // Default loyalty point is set to 0
    }

    // Getter for VAT inclusive price
    public int getVatInclusivePrice() {
        return vatInclusivePrice;
    }

    // Getter for loyalty points
    public int getLoyaltyPoint() {
        return loyaltyPoint;
    }

    // Setter for payment online status
    public void setIsPaymentOnline(boolean isPaymentOnline) {
        this.isPaymentOnline = isPaymentOnline;
    }

    // Method to calculate loyalty points based on VAT inclusive price
    public void calculateLoyaltyPoint() {
        if (isPaymentOnline) {
            // Loyalty points are 1% of the VAT inclusive price
            double loyaltyPercentage = 0.01;
            loyaltyPoint = (int) (vatInclusivePrice * loyaltyPercentage);
        }
    }

    // Method to remove a product based on certain conditions
    public void removeProduct() {
        // Check if the conditions are met to remove the product
        if (loyaltyPoint == 0 && (purchasedYear.equals("2020") || purchasedYear.equals("2021") || purchasedYear.equals("2022"))) {
            // Set VAT inclusive price and loyalty points to 0, and payment online status to false
            vatInclusivePrice = 0;
            loyaltyPoint = 0;
            isPaymentOnline = false;
        }
    }

    // Override toString method to provide a formatted string representation of the Retailer
    @Override
    public String toString() {
        // Call the superclass toString method to include Store details and append Retailer-specific details
        return super.toString() + String.format("\nVAT Inclusive Price: $%d\nLoyalty Point: %d\nPurchased Year: %s\nPayment Online: %b",
                vatInclusivePrice, loyaltyPoint, purchasedYear, isPaymentOnline);
    }
}
