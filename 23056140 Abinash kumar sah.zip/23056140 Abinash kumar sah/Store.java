public class Store {
    // Fields to store information about the store
    private int storeId;
    private String storeName;
    private String location;
    private String openingHour;
    private double totalSales;
    private double totalDiscount;

    // Constructor to initialize a store object
    public Store(int storeId, String storeName, String location, String openingHour) {
        this.storeId = storeId;              // Store ID
        this.storeName = storeName;          // Name of the store
        this.location = location;            // Location of the store
        this.openingHour = openingHour;      // Opening hours of the store
        this.totalSales = 0.0;               // Initialize total sales to 0
        this.totalDiscount = 0.0;            // Initialize total discount to 0
    }

    // Getter for store ID
    public int getStoreId() {
        return storeId;
    }

    // Getter for store name
    public String getStoreName() {
        return storeName;
    }

    // Getter for store location
    public String getLocation() {
        return location;
    }

    // Getter for store opening hours
    public String getOpeningHour() {
        return openingHour;
    }

    // Method to add new sales to the total sales
    public void setTotalSales(double newSales) {
        totalSales += newSales;  // Accumulate new sales
    }

    // Method to add new discounts to the total discount
    public void setTotalDiscount(double newDiscount) {
        totalDiscount += newDiscount;  // Accumulate new discounts
    }

    // Method to display information about the store
    public void displayStoreInfo() {
        System.out.println("Store ID: " + storeId);
        System.out.println("Store Name: " + storeName);
        System.out.println("Location: " + location);
        System.out.println("Opening Hour: " + openingHour);

        // Check if there are any recorded sales or discounts
        if (totalSales == 0.0 && totalDiscount == 0.0) {
            System.out.println("No sales or discounts recorded yet.");
        } else {
            // Display sales and discount if they exist
            System.out.println("Total Sales: $" + totalSales);
            System.out.println("Total Discount: $" + totalDiscount);
        }
    }

    // Override the toString method to provide a formatted string representation of the store
    @Override
    public String toString() {
        return String.format("Store ID: %d\nStore Name: %s\nLocation: %s\nOpening Hour: %s\nTotal Sales: $%.2f\nTotal Discount: $%.2f",
                storeId, storeName, location, openingHour, totalSales, totalDiscount);
    }
}
